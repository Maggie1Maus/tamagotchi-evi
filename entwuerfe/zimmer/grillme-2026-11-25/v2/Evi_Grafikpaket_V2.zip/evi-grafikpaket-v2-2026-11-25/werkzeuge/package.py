"""Create editable OpenRaster scenes and a readable layer index from native exports."""
import io,json,shutil,zipfile,hashlib
from pathlib import Path
from xml.etree.ElementTree import Element,SubElement,tostring
from PIL import Image,ImageChops,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT if (ROOT/'manifest.json').exists() else ROOT/'evi-grafikpaket-v2-2026-11-25'
m=json.loads((OUT/'manifest.json').read_text())
def pngbytes(im):
 b=io.BytesIO();im.save(b,format='PNG');return b.getvalue()
def rgba(asset_id):
 a=m['assets'][asset_id]
 if a['transparent']:return Image.open(OUT/a['transparent']).convert('RGBA')
 return Image.open(OUT/'bausteine'/asset_id/'linien.png').convert('RGBA')

glass=ImageChops.invert(Image.open(OUT/'bausteine/fenster-scheibenmaske/linien.png').convert('L'))
(OUT/'editierbare-szenen').mkdir(exist_ok=True)
for season in ['fruehling','sommer','herbst','winter']:
 state=next(s for s in m['states'] if s['id']==f'{season}-tag-leicht-bewoelkt')
 layers=[]
 for aid in ['raumstruktur','regal','sideboard','tierbett','teppich']:
  a=m['assets'][aid];layers.append((aid,rgba(aid),a['anchor']['x'],a['anchor']['y']))
 for aid in state['layers']:
  a=m['assets'][aid];im=Image.new('RGBA',(66,53));im.paste(rgba(aid),(a['anchor']['x'],a['anchor']['y']))
  im.putalpha(ImageChops.multiply(im.getchannel('A'),glass))
  layers.append((aid,im,79,19))
 for aid in ['fenster-rahmen','evi-vorne']:
  a=m['assets'][aid];layers.append((aid,rgba(aid),a['anchor']['x'],a['anchor']['y']))
 merged=Image.new('RGBA',(320,174),'white')
 for _,im,x,y in layers:merged.alpha_composite(im,(x,y))
 target=Image.open(OUT/state['scene']).convert('RGBA')
 if ImageChops.difference(merged.convert('RGB'),target.convert('RGB')).getbbox():raise RuntimeError('Layer composition mismatch: '+season)
 image=Element('image',{'version':'0.0.3','w':'320','h':'174','name':'Evi '+season})
 stack=SubElement(image,'stack')
 output=OUT/'editierbare-szenen'/f'Evi_{season}_Ebenen.ora'
 with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('mimetype','image/openraster',compress_type=zipfile.ZIP_STORED)
  for index,(name,im,x,y) in enumerate(reversed(layers)):
   src=f'data/layer{index:03}.png';z.writestr(src,pngbytes(im))
   SubElement(stack,'layer',{'name':name,'src':src,'x':str(x),'y':str(y),'opacity':'1.0','visibility':'visible','composite-op':'svg:src-over'})
  z.writestr('stack.xml',tostring(image,encoding='utf-8',xml_declaration=True))
  z.writestr('mergedimage.png',pngbytes(merged))
  thumb=merged.copy();thumb.thumbnail((256,256));z.writestr('Thumbnails/thumbnail.png',pngbytes(thumb))

selected=['baum-fruehling','baum-sommer','baum-herbst','baum-winter','landschaft-huegel-boden','wetter-sonne','wetter-sonne-wolke','wetter-wolke','wetter-regenwolke','mond','sterne','herbstblatt','herbstlaub-boden','winter-schnee-boden','winter-schnee-aeste','regal','sideboard','tierbett','teppich','evi-vorne','fenster-rahmen','regen-05','schneefall-05','himmel-daemmerung-regen','himmel-nacht-klar']
canvas=Image.new('RGB',(1200,1100),'white');d=ImageDraw.Draw(canvas)
fontfile='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font=ImageFont.truetype(fontfile,14) if Path(fontfile).exists() else ImageFont.load_default()
for i,aid in enumerate(selected):
 x=(i%5)*240;y=(i//5)*220
 d.text((x+8,y+8),aid,fill='black',font=font)
 im=rgba(aid);factor=min(3,210//im.width,170//im.height);factor=max(factor,1)
 im=im.resize((im.width*factor,im.height*factor),Image.Resampling.NEAREST)
 canvas.paste(im,(x+(240-im.width)//2,y+35),im)
canvas.save(OUT/'Evi_V2_Ebenenuebersicht.png')
print(json.dumps({'openRasterScenes':4,'layerCompositionsMatch':True,'layerOverview':len(selected)}))
