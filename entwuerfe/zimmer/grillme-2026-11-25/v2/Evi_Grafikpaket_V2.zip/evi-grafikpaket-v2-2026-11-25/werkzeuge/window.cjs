// Native assets from the existing firmware are decoded without generative redraw.
function addWindow({fs,path,ROOT,OUT,INPUT,BUNDLED,W,H,FW,FH,FX,FY,bm,px,get,rect,line,crop,scale,blit,union,dilate,outerMask,png,asset,assets,readRaw,reduceRaw}) {
 const nativeText=fs.readFileSync(BUNDLED?path.join(INPUT,'umgebung-original.h'):path.join(ROOT,'evi-build/weather-source.h'),'utf8');
 function native(name){
  const m=nativeText.match(new RegExp('static const Bild '+name+' = \\{(\\d+), (\\d+),'));
  if(!m)throw Error('Missing original asset '+name);
  const w=+m[1],h=+m[2];
  function decode(suffix){const body=nativeText.match(new RegExp('static const uint8_t '+name+'_'+suffix+'\\[\\] = \\{([\\s\\S]*?)\\};'))[1],bytes=[...body.matchAll(/0x([0-9a-f]{2})/gi)].map(q=>parseInt(q[1],16)),z=bm(w,h);for(let y=0;y<h;y++)for(let x=0;x<w;x++)px(z,x,y,(bytes[y*Math.ceil(w/8)+(x>>3)]>>(7-(x&7)))&1);return z;}
  return {ink:decode('LINIEN'),mask:decode('MASKE')};
 }
 function opaque(ink){return {ink,mask:union(outerMask(ink),dilate(ink,1))};}
 function sprite(id){const a=assets[id];return {ink:a.ink,mask:a.mask||bm(a.width,a.height,new Uint8Array(a.width*a.height).fill(1))};}
 function place(z,id,x,y){const a=sprite(id);blit(z,a.ink,x,y,a.mask);}
 function full(z,id,x,y){const a=sprite(id);blit(z.ink,a.ink,x,y,a.mask);blit(z.mask,a.mask,x,y,a.mask);}
 function circle(z,cx,cy,r,fill=false,v=1){for(let y=cy-r;y<=cy+r;y++)for(let x=cx-r;x<=cx+r;x++){const d=(x-cx)**2+(y-cy)**2;if(d<=r*r&&(fill||d>=(r-1)**2))px(z,x,y,v);}}
 const trees={};
 let ground,groundMask;
 async function init(){
  ground=bm(FW,FH);groundMask=bm(FW,FH);
  const edge=[[0,47],[4,45],[10,44],[15,45],[20,47],[26,48],[31,49],[37,47],[43,48],[49,48],[55,47],[60,46],[65,46]];
  for(let i=1;i<edge.length;i++)line(ground,...edge[i-1],...edge[i]);
  for(let x=0;x<FW;x++){let y=0;while(y<FH&&!get(ground,x,y))y++;for(let yy=y;yy<FH;yy++)px(groundMask,x,yy);}
  await asset('landschaft-huegel-boden',ground,groundMask);
  for(const [s,w]of [['fruehling',34],['sommer',35],['herbst',31],['winter',28]]){
   // Transparent tree layers were reconstructed from the approved preview with
   // imagegen; native-size export below is deterministic and retains full trees.
   const file=BUNDLED?path.join(INPUT,`baum-${s}.png`):path.join(ROOT,'evi-build-v2/tree-source',`baum-${s}.png`);
   const raw=await readRaw(file),{data,info}=raw;let minX=info.width,minY=info.height,maxX=-1,maxY=-1;
   for(let y=0;y<info.height;y++)for(let x=0;x<info.width;x++)if(data[(y*info.width+x)*4+3]>127){minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);}
   const q=reduceRaw(raw,w,45,{x:minX,y:minY,w:maxX-minX+1,h:maxY-minY+1},.28),x=48-Math.floor(w/2),z=bm(FW,FH),m=bm(FW,FH);
   blit(z,q.ink,x,5,q.ink);blit(m,union(q.mask,outerMask(q.ink)),x,5);
   const a={ink:z,mask:union(m,dilate(z,1))};trees[s]=a;await asset('baum-'+s,a.ink,a.mask);
  }
  for(const [id,name,w,h]of [['sonne','WETTER_SONNE',22,22],['sonne-wolke','WETTER_SONNE_WOLKE',26,24],['wolke','WETTER_WOLKE',27,21],['regenwolke','WETTER_REGENWOLKE',27,17]]){const q=native(name),ink=scale(q.ink,w,h),mask=scale(q.mask,w,h);await asset('wetter-'+id,ink,union(mask,dilate(ink,1)));}
  const moon=bm(16,17);circle(moon,7,8,7,true);circle(moon,11,5,6,true,0);const mo=opaque(moon);await asset('mond',mo.ink,mo.mask);
  const stars=bm(FW,FH);for(const[x,y]of [[29,4],[18,30],[4,35],[31,17]]){px(stars,x,y);if(x===29){px(stars,x-1,y);px(stars,x+1,y);px(stars,x,y-1);px(stars,x,y+1);}}const st=opaque(stars);await asset('sterne',st.ink,st.mask);
  const leaf=bm(5,6);for(const p of [[0,3,2,1],[2,1,4,0],[4,0,3,4],[3,4,0,3],[0,5,3,2]])line(leaf,...p);const lf=opaque(leaf);await asset('herbstblatt',lf.ink,lf.mask,{x:19,y:28});
  const foliage=bm(FW,FH);for(const[x,y]of [[36,48],[40,49],[44,48]]){px(foliage,x,y);px(foliage,x+1,y-1);px(foliage,x+2,y);line(foliage,x,y+1,x+2,y+1);}const fo=opaque(foliage);await asset('herbstlaub-boden',fo.ink,fo.mask);
  const snow=bm(FW,FH),sm=bm(FW,FH);for(let x=0;x<FW;x++){let y=0;while(y<FH&&!get(ground,x,y))y++;if(y<FH){px(snow,x,y-1);for(let yy=y-1;yy<FH;yy++)px(sm,x,yy);}}
  await asset('winter-schnee-boden',snow,sm);
  const treeSnow=bm(FW,FH),treeSnowMask=bm(FW,FH),wi=trees.winter.ink;for(const x of [40,41,42,49,50,51,58,59,60]){let y=0;while(y<FH&&!get(wi,x,y))y++;if(y>4&&y<42){px(treeSnow,x,y-1);px(treeSnowMask,x,y-1);}}await asset('winter-schnee-aeste',treeSnow,treeSnowMask);
 }
 const BAYER=[0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5];
 function sky(time,wt){const a=bm(FW,FH),base={tag:0,daemmerung:2,nacht:5}[time],extra={klar:0,'leicht-bewoelkt':0,bedeckt:1,regen:2,schneefall:1}[wt];for(let y=0;y<FH;y++)for(let x=0;x<FW;x++){const threshold=base+extra+(wt==='regen'&&y<16?1:0);if(BAYER[(y%4)*4+x%4]<threshold)px(a,x,y);}return a;}
 function celestial(time,wt){const a={ink:bm(FW,FH),mask:bm(FW,FH)};if(time==='tag'&&wt==='klar')full(a,'wetter-sonne',3,2);if(time==='tag'&&wt==='leicht-bewoelkt')full(a,'wetter-sonne-wolke',2,1);if(time==='daemmerung'&&['klar','leicht-bewoelkt'].includes(wt)){full(a,'wetter-sonne',3,12);if(wt==='leicht-bewoelkt')full(a,'wetter-wolke',4,18);}if(time==='nacht'&&['klar','leicht-bewoelkt'].includes(wt)){full(a,'mond',4,3);if(wt==='klar')full(a,'sterne',0,0);else full(a,'wetter-wolke',6,14);}return a;}
 function clouds(time,wt){const a={ink:bm(FW,FH),mask:bm(FW,FH)};if(['bedeckt','regen','schneefall'].includes(wt))full(a,wt==='regen'?'wetter-regenwolke':'wetter-wolke',2,4);return a;}
 function precip(wt,f=0){const ink=bm(FW,FH),phase=(f%16)/16;if(wt==='regen')for(let i=0;i<6;i++){const travel=(i*17+phase*(FH+8))%(FH+8),y=Math.floor(travel)-5,x=((i*23-Math.floor(travel/3))%FW+FW)%FW;line(ink,x,y,x-2,y+4);}if(wt==='schneefall')for(let i=0;i<8;i++){const x=(i*19+Math.round(Math.sin(phase*Math.PI*2+i)*2)+FW)%FW,y=Math.floor((i*13+phase*(FH+6))%(FH+6))-3;px(ink,x,y);if(i%3===0){px(ink,x-1,y);px(ink,x+1,y);px(ink,x,y-1);px(ink,x,y+1);}}return {ink,mask:dilate(ink,1)};}
 function window(season,time,wt,f=0,settled=false){if(wt==='schneefall'&&season!=='winter')throw Error('Snowfall outside winter');const z=sky(time,wt),c=celestial(time,wt),cl=clouds(time,wt);blit(z,c.ink,0,0,c.mask);blit(z,cl.ink,0,0,cl.mask);blit(z,ground,0,0,groundMask);const t=trees[season];blit(z,t.ink,0,0,t.mask);if(season==='herbst'){place(z,'herbstlaub-boden',0,0);const phase=(f%16)/16;place(z,'herbstblatt',19+Math.round(Math.sin(phase*2*Math.PI)*2),28+Math.floor(phase*18));}if(settled&&season==='winter'){place(z,'winter-schnee-boden',0,0);place(z,'winter-schnee-aeste',0,0);}const p=precip(wt,f);blit(z,p.ink,0,0,p.mask);return z;}
 return {init,native,sky,celestial,clouds,precip,window,trees};
}
module.exports=addWindow;
