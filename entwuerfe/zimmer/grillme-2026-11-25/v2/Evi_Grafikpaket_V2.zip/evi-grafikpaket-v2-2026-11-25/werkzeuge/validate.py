"""Verify actual exported bitmaps, layer composition, animation clipping and C++ data."""
import json,re,hashlib,subprocess,tempfile,shutil,zipfile,io
from pathlib import Path
from collections import deque
from PIL import Image,ImageChops

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT if (ROOT/'manifest.json').exists() else ROOT/'evi-grafikpaket-v2-2026-11-25'
m=json.loads((OUT/'manifest.json').read_text());checks={}
def ink(aid):return ImageChops.invert(Image.open(OUT/'bausteine'/aid/'linien.png').convert('L'))
def count(im):return sum(v>0 for v in im.tobytes())
binary=alpha=animation=0
for f in OUT.rglob('*'):
 if not f.is_file() or 'quellen' in f.relative_to(OUT).parts:continue
 if f.suffix=='.png':
  im=Image.open(f)
  if f.name=='freigestellt.png':
   assert set(im.convert('RGBA').tobytes())<={0,255},f;alpha+=1
  elif f.name=='Evi_V2_Ebenenuebersicht.png':pass # labels only, not a device asset
  else:
   assert im.mode=='1',(str(f),im.mode);binary+=1
 if f.suffix=='.gif':
  im=Image.open(f);duration=0;first=None
  assert 2<=im.n_frames<=16,(f,im.n_frames)
  assert im.size==(960,522)
  # Only the glass can move; bars, Evi and the interior must stay fixed.
  glass=ink('fenster-scheibenmaske');allowed=Image.new('L',(320,174));allowed.paste(glass,(79,19));allowed=allowed.resize((960,522),Image.Resampling.NEAREST)
  for n in range(im.n_frames):
   im.seek(n);frame=im.convert('RGB');duration+=im.info['duration']
   assert set(frame.tobytes())<={0,255},f
   if first is None:first=frame
   else:assert not ImageChops.multiply(ImageChops.difference(frame,first).convert('L'),ImageChops.invert(allowed)).getbbox(),f
  expected=3520 if 'fallendes-blatt' in f.name else 3040 if 'schneefall' in f.name else 1760
  assert duration==expected,(f,duration);assert im.info.get('loop',0)==0;animation+=1
checks['binary_device_png']={'passed':True,'count':binary,'bitDepth':1}
checks['binary_rgba_layers']={'passed':True,'count':alpha}
checks['animation_timing_and_clipping']={'passed':True,'count':animation,'frames':16}

assert len(m['states'])==51;assert len({s['id'] for s in m['states']})==51
assert all(s['season']=='winter' for s in m['states'] if s['weather']=='schneefall')
glass=ink('fenster-scheibenmaske');allowed=Image.new('L',(320,174));allowed.paste(glass,(79,19))
first=Image.open(OUT/m['states'][0]['scene']).convert('L')
for s in m['states']:
 im=Image.open(OUT/s['scene']).convert('L');assert im.size==(320,174)
 assert not ImageChops.multiply(ImageChops.difference(im,first),ImageChops.invert(allowed)).getbbox(),s['id']
checks['states_and_fixed_interior']={'passed':True,'count':51,'snowfallOnlyInWinter':True}

for time in ['tag','daemmerung','nacht']:
 for weather in ['regen','schneefall','bedeckt']:
  assert count(ink(f'wolken-{time}-{weather}'))>20,(time,weather,'missing cloud')
  assert count(ink(f'himmelszeichen-{time}-{weather}'))==0,(time,weather,'unexpected celestial body')
for weather in ['klar','leicht-bewoelkt','bedeckt','regen','schneefall']:
 levels=[count(ink(f'himmel-{time}-{weather}')) for time in ['tag','daemmerung','nacht']]
 assert levels[0]<levels[1]<levels[2],(weather,levels)
for time in ['tag','daemmerung','nacht']:
 assert count(ink(f'himmel-{time}-regen'))>count(ink(f'himmel-{time}-klar'))
checks['clouds_celestial_bodies_and_darkness']={'passed':True,'rainCloudPresent':True,'threeDistinctTimes':True,'rainDarker':True}

for s in ['fruehling','sommer','herbst','winter']:
 im=ink('baum-'+s);assert any(im.getpixel((x,49)) for x in range(im.width)),(s,'root not on baseline')
 silhouette=ImageChops.invert(Image.open(OUT/'bausteine'/('baum-'+s)/'deckmaske.png').convert('L'))
 pts={(x,y) for y in range(im.height) for x in range(im.width) if silhouette.getpixel((x,y))}
 # A complete connected tree must survive export, including its smallest twigs.
 sizes=[]
 while pts:
  p=pts.pop();todo=[p];n=0
  while todo:
   x,y=todo.pop();n+=1
   for dx,dy in [(-1,-1),(0,-1),(1,-1),(-1,0),(1,0),(-1,1),(0,1),(1,1)]:
    q=x+dx,y+dy
    if q in pts:pts.remove(q);todo.append(q)
  sizes.append(n)
 assert max(sizes)/sum(sizes)>.97,(s,sizes)
checks['complete_rooted_trees']={'passed':True,'seasons':4,'baselineY':49}

source=OUT/'quellen/bausteine'
for aid in ['regal','sideboard','tierbett','teppich','evi-vorne','evi-original-nativ']:
 for name in ['linien.pbm','deckmaske.pbm']:
  assert (OUT/'bausteine'/aid/name).read_bytes()==(source/aid/name).read_bytes(),(aid,name)
checks['original_evi_and_furniture']={'passed':True,'unchangedNativePixels':True}
ora=list((OUT/'editierbare-szenen').glob('*.ora'));assert len(ora)==4
for f in ora:
 season=f.stem.removeprefix('Evi_').removesuffix('_Ebenen')
 with zipfile.ZipFile(f) as z:
  assert z.namelist()[0]=='mimetype' and z.read('mimetype')==b'image/openraster'
  merged=Image.open(io.BytesIO(z.read('mergedimage.png'))).convert('RGB')
  target=Image.open(OUT/'ansichten'/f'{season}-tag-leicht-bewoelkt.png').convert('RGB')
  assert not ImageChops.difference(merged,target).getbbox(),f
checks['editable_scenes_match_png']={'passed':True,'count':4}
header=(OUT/'integration/evi_grafiken.h').read_text()
total=0
for aid,a in m['assets'].items():
 for suffix,key in [('LINIEN','ink'),('MASKE','mask')]:
  if not a[key]:continue
  raw=(OUT/a[key]).read_bytes();p=re.match(rb'P4\n(\d+) (\d+)\n',raw);expected=raw[p.end():]
  name='EVI_'+aid.replace('-','_').upper()+'_'+suffix
  match=re.search(name+r'\[\] = \{(.*?)\};',header,re.S);assert match,name
  got=bytes(int(h,16) for h in re.findall(r'0x([0-9a-f]{2})',match[1]));assert got==expected,name;total+=len(got)
 if a['mask']:
  opacity=ImageChops.invert(Image.open(OUT/'bausteine'/aid/'deckmaske.png').convert('L'))
  assert not ImageChops.multiply(ink(aid),ImageChops.invert(opacity)).getbbox(),aid
checks['cpp_arrays_and_masks']={'passed':True,'assets':len(m['assets']),'packedBitmapBytes':total}
if shutil.which('g++'):
 with tempfile.TemporaryDirectory() as td:
  src=Path(td)/'check.cpp';src.write_text('#include "'+str(OUT/'integration/evi_grafiken.h')+'"\nint main(){return 0;}\n')
  subprocess.run(['g++','-std=c++11','-fsyntax-only',str(src)],check=True,capture_output=True)
 checks['cpp_header_syntax']={'passed':True,'standard':'C++11'}
report={'version':2,'date':'2026-11-25','status':'passed','checks':checks,'limitations':['Graphics package only; app integration is still pending.','High-resolution sources are references; only native exports carry the binary-color guarantee.','Depth scaling, furniture movement and placement rules are outside this graphics export.']}
(OUT/'Pruefbericht.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
