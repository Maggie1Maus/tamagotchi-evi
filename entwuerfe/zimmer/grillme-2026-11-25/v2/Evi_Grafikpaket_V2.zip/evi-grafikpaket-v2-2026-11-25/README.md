# Evi – Grafikpaket V2

Grundlage ist die am 25. November 2026 bestätigte Vorschau mit vollständigem Herbstbäumchen, Hügeln und großer Sonne mit Wolke. Diese Fassung ersetzt den verworfenen Fensterausblick mit dem schwebenden Zweig.

## Direkt ansehen

| Datei | Inhalt |
| --- | --- |
| `Evi_V2_Muster_320x174.png` | Herbst, Tag, leicht bewölkt in nativer Spielgröße |
| `Evi_V2_Muster_4x.png` | Derselbe Export vierfach vergrößert, ohne Glättung |
| `Evi_V2_Vier_Jahreszeiten.png` | Vier Jahreszeiten bei gleichem Wetter und Tageslicht |
| `Evi_V2_Wetter_und_Tageszeiten.png` | Tag, Dämmerung, Nacht, Regen, Schnee und optional liegender Schnee |
| `Evi_V2_Ebenenuebersicht.png` | Übersicht der wichtigsten getrennten Bestandteile |
| `animationen/` | 16 animierte Vorschauen: Regen für alle Jahreszeiten/Tageszeiten, Winterschnee und Herbstblatt |
| `uebersichten/` | Jede Jahreszeit mit sämtlichen gültigen Wetter- und Tageszeitkombinationen |
| `editierbare-szenen/` | Vier OpenRaster-Dateien mit benannten Ebenen, zum Öffnen in Krita oder GIMP |

## Gestaltung und Zustände

Die Bäume stehen mit sichtbarem Stamm auf dem Boden. Die Baumebenen enthalten vollständige Formen; Fensterkreuz und Rahmen werden davor gezeichnet. Jahreszeiten, Wetter und Tageszeit bleiben unabhängig kombinierbar.

| Einfluss | Darstellung |
| --- | --- |
| Frühling | Baumkrone mit Blüten |
| Sommer | Volle, belaubte Krone |
| Herbst | Wenige Blätter, eigenes Laub am Boden und ein separates fallendes Blatt |
| Winter | Kahle Äste; Schnee auf Boden und Ästen optional separat |
| Klarer Tag | Große Sonne |
| Leicht bewölkter Tag | Große Sonne mit überlagernder Wolke |
| Bedeckt | Wolke ohne sichtbare Sonne oder Mond |
| Regen | Regenwolke, dichteres Punktraster im Himmel, bewegte Regenstriche |
| Schneefall | Wolke und bewegte Flocken, ausschließlich im Winter |
| Dämmerung | Eigenes Punktraster, bei sichtbarem Himmel tief stehende Sonne |
| Nacht | Dichteres Punktraster; Mond und Sterne bei klarem Himmel, Mond mit Wolke bei leichter Bewölkung |

Es gibt **51 gültige Kombinationen**: vier Jahreszeiten, drei Tageszeiten, vier allgemeine Wetterlagen sowie Schneefall in den drei Winter-Tageszeiten. Liegender Schnee ist eine zusätzliche optionale Ebene, kein automatisch erzwungener Zustand. Alle Wetteränderungen sind auf das Fensterglas begrenzt.

Die Original-Evi und die vorhandenen nativen Möbelgrafiken sind unverändert übernommen. Die vier Baumebenen wurden anhand der bestätigten Vorschau separat freigestellt beziehungsweise saisonal abgeleitet. Die Wettergrafiken stammen aus den vorhandenen Projektgrafiken und werden deutlich größer verwendet als im verworfenen Paket.

## Getrennte Ebenen

Jeder Baustein befindet sich unter `bausteine/NAME/`:

| Datei | Bedeutung |
| --- | --- |
| `linien.png` / `linien.pbm` | Schwarze Linien und Flächen; echte 1-Bit-Dateien |
| `deckmaske.png` / `deckmaske.pbm` | Schwarz bedeutet deckend, Weiß bedeutet durchsichtig |
| `freigestellt.png` | Schwarze und weiße Grafik mit echtem transparentem Außenbereich; RGBA mit binärem Alpha |

Baum, Landschaft, Wetterzeichen, Wolken, Himmel, Niederschlag, Laub, Fensterrahmen, Möbel und Figur sind einzeln vorhanden. Die 16 Regen- und 16 Schneefallphasen sind ebenfalls als getrennte Bausteine exportiert. Leere Himmelszeichen- oder Wolkenebenen sind für Zustände ohne dieses Element absichtlich transparent.

Die Dateien unter `ansichten/` sind zusammengesetzte Kontrollen. Für die flexible Umsetzung die einzelnen Ebenen verwenden. Die vier `.ora`-Dateien enthalten dieselben tatsächlichen Spielgrafiken als benannte, bearbeitbare Ebenen. Ihre zusammengefügten Bilder stimmen pixelgenau mit den entsprechenden PNG-Ansichten überein.

## Koordinaten und Zeichenreihenfolge

Die Szene ist **320 × 174 Pixel** groß. Der Fensterausblick liegt bei **x = 79, y = 19**, seine lokale Fläche ist **66 × 53 Pixel**. `manifest.json` enthält Maße, Dateipfade, Ausgangspositionen und die Zeichenreihenfolge pro Zustand.

`anchorSpace: room` bezeichnet eine Position im ganzen Zimmer. `anchorSpace: window` bezeichnet eine Position im lokalen Fensterausblick. Das Herbstblatt beginnt dort bei x = 19, y = 28; die Animation verschiebt es von dieser Ausgangslage aus. Masken und Transparenz dürfen beim Zeichnen nicht ignoriert werden.

1. Raumstruktur und Möbel zeichnen.
2. Himmel, Himmelszeichen, Wolken, Landschaft und saisonalen Baum zusammensetzen.
3. Optional Laub und liegenden Schnee ergänzen.
4. Regen beziehungsweise Schneefall im Vordergrund des Ausblicks zeichnen.
5. Den Ausblick ausschließlich durch `fenster-scheibenmaske` ins Zimmer übernehmen.
6. Fensterrahmen und Fensterkreuz davor zeichnen; Evi an ihrer Bodenposition ergänzen.

Die Figur bleibt als Ausgangsposition bei x = 140, y = 92. Möbelpositionen sind die Anordnung der Vorschau und keine neue Platzierungsregel. Slotraster, Möbelbewegung, Laufwege und Tiefenskalierung werden beim Einbau in die App angeschlossen.

## Firmware-Export und Reproduktion

`integration/evi_grafiken.h` enthält die einzelnen Linien und Masken als gepackte C++-Arrays. Ein gesetztes Bit bedeutet schwarze Tinte beziehungsweise Deckkraft. Jede Zeile beginnt auf einem ganzen Byte; das höchstwertige Bit ist links. `stride` im Manifest gibt die Byteanzahl je Zeile an. Eine fehlende Maske bedeutet eine vollständig deckende Grafik.

Die unveränderten hochauflösenden Quellen und die bestätigte Vorschau liegen unter `quellen/`. Diese Arbeitsquellen können geglättete Kanten enthalten. Die exportierten Spiel-PNGs haben ausschließlich Schwarz und Weiß; RGBA-Ebenen zusätzlich vollständig transparente Pixel.

Der Export lässt sich ohne erneute Bildgenerierung reproduzieren:

```sh
node werkzeuge/build.cjs
python3 werkzeuge/package.py
python3 werkzeuge/validate.py
```

Dafür werden Node.js mit `sharp` und Python mit Pillow benötigt. Wenn `g++` vorhanden ist, prüft die Validierung zusätzlich die C++11-Syntax des Headers.

## Prüfung und Einbau

`Pruefbericht.json` dokumentiert die Farb-, Masken-, Zustands-, Animations- und Exportprüfungen. Geprüft werden auch unveränderte Originalpixel von Evi und Möbeln, der feste Innenraum in allen Ansichten, vollständige Bäume mit Bodenposition, Regenwolken und die drei unterscheidbaren Tageszeiten.

Dieses Paket liefert die Grafiken und ihre Ebenen für den Einbau. Es wurde noch nicht mit der Handy-App oder Firmware verbunden. Die freigegebene Gestaltung bleibt die Referenz für diesen Einbau.
