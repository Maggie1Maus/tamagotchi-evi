# Bildquellen und Aufträge

Die hochauflösenden Baumebenen wurden mit der integrierten Bildgenerierung aus der bestätigten Zimmer-Vorschau abgeleitet. Die Freistellung besitzt echten Alphakanal. Native Farben, Masken und Bitmaps werden anschließend deterministisch exportiert.

Gemeinsamer Auftrag: Das kleine Bäumchen aus der rechten Fensterhälfte als vollständige, zusammenhängende Form freistellen. Die hinter dem Fensterkreuz verdeckten Stellen ergänzen. Stamm und Verzweigungen, Proportionen und schlichte Pixelkonturen aus der bestätigten Vorschau beibehalten. Nur der Baum, transparenter Außenbereich, schwarz-weiße Grafik, weiße Kronen- und Blattinnenflächen deckend weiß. Keine Landschaft, kein Fenster, kein Wetter, keine Figur, keine Texte. Auf ungefähr 32 × 45 native Pixel reduzierbar halten.

- Herbst: Wenige große umrandete Blätter, verzweigte Äste und kräftiger Stamm wie in der bestätigten Vorschau.
- Frühling: Derselbe Baum mit kompakter runder Krone und drei einfachen Blüten.
- Sommer: Derselbe Baum mit geschlossener belaubter Krone und wenigen lesbaren Blattmarkierungen.
- Winter, finaler Korrekturauftrag: Alle sechs ovalen Blätter einschließlich weißer Innenfläche und schwarzer Kontur entfernen. Stamm und Verzweigungen erhalten, die Zweige als kahle kurze Spitzen enden lassen. Nur zusammenhängende schwarze Stamm- und Astsilhouette auf transparentem Hintergrund. Keine geschlossenen ovalen Formen, keine Krone, kein Schnee.

Die Wetterzeichen werden aus den vorhandenen nativen Projektdaten übernommen. Figur und Möbel werden unverändert aus den vorhandenen nativen Ebenen kopiert. Zum erneuten Export ist keine weitere Bildgenerierung erforderlich.
